@echo off
title ScanQC - Stop
echo Stopping ScanQC...

REM 1) Ask the server to shut down by itself
powershell -NoProfile -ExecutionPolicy Bypass -Command "try{Invoke-WebRequest -UseBasicParsing -Method Post -TimeoutSec 3 http://127.0.0.1:8507/api/shutdown | Out-Null; 'ok'}catch{}" >nul 2>nul
timeout /t 1 >nul

REM 2) Force-kill whatever still holds port 8507 (works on Korean / English Windows)
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-NetTCPConnection -LocalPort 8507 -ErrorAction SilentlyContinue | Select-Object -ExpandProperty OwningProcess -Unique | Where-Object {$_ -gt 0} | ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }" >nul 2>nul

REM 3) Fallback without PowerShell: last column of netstat is the PID
for /f "tokens=*" %%L in ('netstat -ano ^| findstr /C:"127.0.0.1:8507 "') do (
    for %%P in (%%L) do set "LASTPID=%%P"
    call taskkill /PID %%LASTPID%% /F >nul 2>nul
)

echo ScanQC stopped.
timeout /t 2 >nul
