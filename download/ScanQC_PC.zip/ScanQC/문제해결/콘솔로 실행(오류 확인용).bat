@echo off
chcp 65001 > nul
title ScanQC - Scan Review Tool
cd /d "%~dp0.."

REM ---- find Python: this folder, parent folder, or HP Review dist_portable next to it
set "PYEXE="
for %%P in ("%~dp0..\python\python.exe") do (
    if not defined PYEXE if exist %%P set "PYEXE=%%~P"
)
if not defined PYEXE (
    where python >nul 2>nul && set "PYEXE=python"
)
if not defined PYEXE goto nopython

echo Python : %PYEXE%
"%PYEXE%" -c "import sys, numpy, PIL; print('version:', sys.version.split()[0], '/ Pillow', PIL.__version__, '/ numpy', numpy.__version__)"
if errorlevel 1 goto nolib

echo ==============================================
echo   ScanQC  -  http://127.0.0.1:8507
echo   Browser opens automatically.
echo   To exit: close this window, or run stop.bat
echo ==============================================
"%PYEXE%" server.py --keep-alive
if errorlevel 1 goto crashed
exit /b 0

:crashed
echo.
echo [ERROR] ScanQC stopped with an error. See the message above.
echo         The same text is saved in data\error.log
pause
exit /b 1

:nopython
echo [ERROR] Python not found.
echo   Copy the "python" folder from HP Review dist_portable
echo   into: %~dp0
pause
exit /b 1

:nolib
echo.
echo [ERROR] numpy / Pillow could not be loaded from: %PYEXE%
echo   Use the python folder from HP Review dist_portable.
pause
exit /b 1
