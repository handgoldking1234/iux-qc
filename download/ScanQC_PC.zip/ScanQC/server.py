# -*- coding: utf-8 -*-
"""ScanQC - 스캔 이미지 검수/보정 도구 (로컬 서버)

필요: Python 3.8+, Pillow, numpy  (기존 HP Review 포터블 python 폴더에 이미 포함)
실행: python server.py  ->  http://127.0.0.1:8507
"""
import os, sys, io, re, csv, json, time, shutil, hashlib, threading, traceback, webbrowser, subprocess, base64, struct, atexit
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, parse_qs
from concurrent.futures import ThreadPoolExecutor
from collections import OrderedDict

import numpy as np
from PIL import Image, ImageDraw

Image.MAX_IMAGE_PIXELS = None
RS = getattr(Image, "Resampling", Image)
TP = getattr(Image, "Transpose", Image)
DT = getattr(Image, "Dither", Image)

VERSION = "1.0.0"
APP_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC = os.path.join(APP_DIR, "static")
DATA = os.path.join(APP_DIR, "data")
SESS_DIR = os.path.join(DATA, "sessions")
BACKUP_DIR = os.path.join(DATA, "backup")
CFG_PATH = os.path.join(DATA, "config.json")
LOG_PATH = os.path.join(DATA, "log.csv")
for _d in (DATA, SESS_DIR, BACKUP_DIR):
    os.makedirs(_d, exist_ok=True)

# 창 없이(pythonw) 실행되면 출력 대상이 없으므로 로그 파일로 보냄
if sys.stdout is None or sys.stderr is None:
    _log = open(os.path.join(DATA, "server.log"), "a", encoding="utf-8", buffering=1)
    sys.stdout = sys.stdout or _log
    sys.stderr = sys.stderr or _log

PORT = int(os.environ.get("SCANQC_PORT", "8507"))
EXTS = (".tif", ".tiff", ".jpg", ".jpeg", ".png", ".bmp")
FMT = {".tif": "TIFF", ".tiff": "TIFF", ".jpg": "JPEG", ".jpeg": "JPEG", ".png": "PNG", ".bmp": "BMP"}

DEFAULT_CFG = {
    "hp_dir": "", "orig_dir": "",
    "preview": 1200,        # 미리보기 긴 변(px). 작을수록 빨리 읽음 · 확대하면 원래 크기를 따로 불러옴
    "auto_mode": "balance", # paper=용지 경계, balance=용지+좌우 여백 균등, content=내용+여백
    "margin_mm": 10,        # 내용+여백 모드의 여백
    "skew_warn": 0.3,       # 기울기 경고 기준(도)
    "backup": True,         # 첫 덮어쓰기 전 data/backup 에 보관
    "prefetch": 2,          # 미리 읽어 둘 다음 파일 수
    "on_load": "hp",        # auto=불러올 때 원본에서 자동 보정 / hp=보정본 파일 그대로 보기
    "trim_px": 2,           # 자동 보정: 상하좌우 가장자리 줄을 최대 몇 px 까지 자를지 (회전은 안 함)
    "label_rot": False,     # 라벨 번호가 정면으로 보이게 90° 단위로 돌리기
    "trim_unit": "mm",      # trim_px 단위: px 또는 mm (mm 은 DPI 로 환산)
    "auto_sec": 3,          # 자동 넘김 간격(초)
    "cfgv": 5,              # 설정 판(올라가면 기본값 일부를 새 값으로)
}


# ---------------------------------------------------------------- utils
def load_json(p, d):
    try:
        with open(p, "r", encoding="utf-8") as f:
            v = json.load(f)
        if isinstance(d, dict):
            x = dict(d); x.update(v); return x
        return v
    except Exception:
        return dict(d) if isinstance(d, dict) else d


def save_json(p, v):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    tmp = p + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(v, f, ensure_ascii=False, indent=1)
    os.replace(tmp, p)


CFG = load_json(CFG_PATH, DEFAULT_CFG)
if not isinstance(load_json(CFG_PATH, {}).get("cfgv"), int) or load_json(CFG_PATH, {}).get("cfgv") < 2:  # 가장자리 정리 기본값: 2mm 안쪽 지저분한 테두리만
    CFG.update(trim_px=2, trim_unit="mm", cfgv=2)
if not isinstance(load_json(CFG_PATH, {}).get("cfgv"), int) or load_json(CFG_PATH, {}).get("cfgv") < 3:  # 시작할 때 자동 보정 끔 (F 로 직접 적용)
    CFG.update(on_load="hp", label_rot=False, cfgv=3)
if not isinstance(load_json(CFG_PATH, {}).get("cfgv"), int) or load_json(CFG_PATH, {}).get("cfgv") < 4:  # 넘김이 빠르게 다음 2장 미리 읽기
    CFG.update(prefetch=max(2, int(CFG.get("prefetch") or 0)), cfgv=4)
if not isinstance(load_json(CFG_PATH, {}).get("cfgv"), int) or load_json(CFG_PATH, {}).get("cfgv") < 5:  # 빨리 읽게 미리보기 기본 1200px (직접 바꾼 값은 그대로)
    if int(CFG.get("preview") or 2400) == 2400:
        CFG["preview"] = 1200
    CFG["cfgv"] = 5


def natkey(s):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", s)]


def folder_tag(d):
    base = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", os.path.basename(os.path.normpath(d)) or "root")
    return base + "_" + hashlib.md5(os.path.normcase(os.path.abspath(d)).encode("utf-8")).hexdigest()[:8]


def clean_path(p):
    return (p or "").strip().strip('"').strip("'").strip()


_locks, _guard = {}, threading.Lock()


def plock(path):
    k = os.path.normcase(os.path.abspath(path))
    with _guard:
        l = _locks.get(k)
        if l is None:
            l = _locks[k] = threading.RLock()
        return l


class LRU:
    def __init__(self, n):
        self.n, self.d, self.l = n, OrderedDict(), threading.Lock()

    def get(self, k):
        with self.l:
            v = self.d.get(k)
            if v is not None:
                self.d.move_to_end(k)
            return v

    def put(self, k, v):
        with self.l:
            self.d[k] = v; self.d.move_to_end(k)
            while len(self.d) > self.n:
                self.d.popitem(last=False)


PREV, INFO = LRU(14), LRU(80)


def sig(path):
    try:
        st = os.stat(path)
        return (os.path.normcase(path), st.st_mtime_ns, st.st_size)
    except (OSError, TypeError):
        return None


# ---------------------------------------------------------------- state
ST = {"hp_dir": "", "orig_dir": "", "files": [], "byname": {}, "sess": None, "sess_path": None, "gen": 0}
ST_LOCK = threading.RLock()
EXEC = ThreadPoolExecutor(max_workers=2)
NCPU = os.cpu_count() or 2
PF_LANES = max(1, min(4, NCPU // 2))  # 미리 읽기를 몇 장 동시에 할지 (코어 4개면 2장, 8개 이상이면 4장) · 메모리 한도는 MemGate 가 따로 지킴
DEC = ThreadPoolExecutor(max_workers=max(4, 2 * PF_LANES + 2))  # 이미지 압축 풀기 전용 (원본·보정본 동시)


SESS_T = {"t": None}


def sess_flush():
    """세션(검수 상태) 파일을 지금 바로 기록"""
    with ST_LOCK:
        t, SESS_T["t"] = SESS_T["t"], None
        if t:
            t.cancel()
        if ST["sess_path"] and ST["sess"] is not None:
            try:
                save_json(ST["sess_path"], ST["sess"])
            except Exception:
                traceback.print_exc()


def sess_save():
    """파일이 수천 장이면 세션 파일도 커서, 넘길 때마다 쓰지 않고 1.5초 모아서 한 번에 기록"""
    with ST_LOCK:
        if not ST["sess_path"] or SESS_T["t"]:
            return
        t = threading.Timer(1.5, sess_flush)
        t.daemon = True
        SESS_T["t"] = t
        t.start()


def set_status(name, status, last=None):
    with ST_LOCK:
        if ST["sess"] is None:
            return
        if status is not None:
            ST["sess"]["statuses"][name] = status
        if last:
            ST["sess"]["last"] = name
        sess_save()


def log(action, name, detail=""):
    try:
        new = not os.path.exists(LOG_PATH)
        with open(LOG_PATH, "a", newline="", encoding="utf-8-sig") as f:
            w = csv.writer(f)
            if new:
                w.writerow(["time", "hp_folder", "file", "action", "detail"])
            w.writerow([time.strftime("%Y-%m-%d %H:%M:%S"), ST["hp_dir"], name, action, detail])
    except Exception:
        traceback.print_exc()


def list_images(d, skip=()):
    """하위 폴더까지 모두 찾음 · 키 = 하위 경로+이름(확장자 뺀 소문자), 값 = 하위 경로 (예: 0001/0001-001.tif)
    os.scandir 로 한 번에 읽어 네트워크 드라이브에서도 파일마다 따로 묻지 않음"""
    out = {}
    skip = {os.path.normcase(os.path.realpath(x)) for x in skip if x}
    stack = [("", d)]
    while stack:
        rel, path = stack.pop()
        try:
            it = os.scandir(path)
        except OSError:
            continue
        with it:
            for e in it:
                n = e.name
                if n.startswith(".") or n.startswith("~"):
                    continue
                r = rel + "/" + n if rel else n
                try:
                    if e.is_dir():
                        if os.path.normcase(os.path.realpath(e.path)) not in skip:
                            stack.append((r, e.path))
                        continue
                    stem, ext = os.path.splitext(r)
                    if ext.lower() in EXTS and e.is_file():
                        out.setdefault(stem.lower(), r)
                except OSError:
                    continue
    return out


def open_folders(hp, orig):
    hp, orig = clean_path(hp), clean_path(orig)
    if not os.path.isdir(hp):
        raise ValueError("보정본(HP) 폴더를 찾을 수 없습니다: " + hp)
    if not os.path.isdir(orig):
        raise ValueError("원본 폴더를 찾을 수 없습니다: " + orig)
    nh, no = os.path.normcase(os.path.realpath(hp)), os.path.normcase(os.path.realpath(orig))
    if nh == no:
        raise ValueError("원본 폴더와 보정본 폴더가 같아요 · 같으면 원본이 덮어써지니 다른 폴더를 고르세요")
    H, O = list_images(hp, skip=[orig]), list_images(orig, skip=[hp])
    stems = sorted(set(H) | set(O), key=natkey)
    files = []
    for s in stems:
        hn, on = H.get(s), O.get(s)
        files.append({"name": hn or on, "rel": hn or on, "hp": os.path.join(hp, *(hn.split("/"))) if hn else None,
                      "orig": os.path.join(orig, *(on.split("/"))) if on else None})
    sp = os.path.join(SESS_DIR, folder_tag(hp) + ".json")
    sess = load_json(sp, {"hp": hp, "orig": orig, "statuses": {}, "last": None})
    flush_drafts()  # 다른 폴더를 열기 전에 이전 폴더의 남은 수정 저장
    sess_flush()
    with ST_LOCK:
        ST.update(hp_dir=hp, orig_dir=orig, files=files, byname={f["name"]: f for f in files},
                  sess=sess, sess_path=sp, gen=ST["gen"] + 1)
    CFG["hp_dir"], CFG["orig_dir"] = hp, orig
    save_json(CFG_PATH, CFG)
    stt = sess["statuses"]
    resume = 0
    if sess.get("last") in ST["byname"]:
        resume = next(i for i, f in enumerate(files) if f["name"] == sess["last"])
    else:
        resume = next((i for i, f in enumerate(files) if not stt.get(f["name"])), 0)
    return {"files": [{"name": f["name"], "hp": bool(f["hp"]), "orig": bool(f["orig"]),
                       "status": stt.get(f["name"], "")} for f in files],
            "resume": resume, "hp_dir": hp, "orig_dir": orig}


SINGLE_DIR = os.path.join(DATA, "single")


def open_file(path):
    """파일 하나만 열어 보정: 원본 = 처음 연 때의 사본(data/single), 저장 = 그 파일에 덮어쓰기 (처음 덮어쓸 때 백업)"""
    path = clean_path(path)
    if not os.path.isfile(path):
        raise ValueError("파일을 찾을 수 없습니다: " + path)
    if os.path.splitext(path)[1].lower() not in EXTS:
        raise ValueError("TIF·JPG·PNG·BMP 이미지 파일만 열 수 있어요")
    d, n = os.path.dirname(path), os.path.basename(path)
    keep = os.path.join(SINGLE_DIR, folder_tag(d))
    os.makedirs(keep, exist_ok=True)
    snap = os.path.join(keep, n)
    if not os.path.exists(snap):
        shutil.copy2(path, snap)
    files = [{"name": n, "hp": path, "orig": snap}]
    sp = os.path.join(SESS_DIR, "single_" + folder_tag(path) + ".json")
    sess = load_json(sp, {"hp": d, "orig": keep, "statuses": {}, "last": None})
    flush_drafts()
    with ST_LOCK:
        ST.update(hp_dir=d, orig_dir=keep, files=files, byname={n: files[0]}, sess=sess, sess_path=sp, gen=ST["gen"] + 1)
    return {"files": [{"name": n, "hp": True, "orig": True, "status": sess["statuses"].get(n, "")}],
            "resume": 0, "hp_dir": d, "orig_dir": keep, "single": path}


def pick_file(initial):
    """Windows 파일 열기 창 (취소 시 빈 문자열)"""
    import subprocess, base64
    initial = clean_path(initial)
    ini = initial if os.path.isdir(initial) else (os.path.dirname(initial) if os.path.isfile(initial) else "")
    if os.name != "nt":
        try:
            import tkinter as tk
            from tkinter import filedialog
            r = tk.Tk(); r.withdraw(); r.attributes("-topmost", True)
            v = filedialog.askopenfilename(title="보정할 파일 하나 선택", initialdir=ini or None,
                                           filetypes=[("스캔 이미지", "*.tif *.tiff *.jpg *.jpeg *.png *.bmp"), ("모든 파일", "*.*")]) or ""
            r.destroy()
            return os.path.normpath(v) if v else ""
        except Exception:
            raise ValueError("이 환경에서는 파일 선택 창을 열 수 없습니다. 경로를 직접 입력하세요")
    esc = lambda t: (t or "").replace("'", "''")
    ps = (
        "[Console]::OutputEncoding=[Text.Encoding]::UTF8\n"
        "Add-Type -AssemblyName System.Windows.Forms\n"
        "$o=New-Object System.Windows.Forms.Form -Property @{TopMost=$true;ShowInTaskbar=$false;Opacity=0;StartPosition='CenterScreen'}\n"
        "$o.Show();$o.Activate()\n"
        "$d=New-Object System.Windows.Forms.OpenFileDialog;$d.Title='보정할 파일 하나 선택'\n"
        "$d.Filter='스캔 이미지|*.tif;*.tiff;*.jpg;*.jpeg;*.png;*.bmp|모든 파일|*.*'\n"
        "if('" + esc(ini) + "'){$d.InitialDirectory='" + esc(ini) + "'}\n"
        "$r='';if($d.ShowDialog($o) -eq [System.Windows.Forms.DialogResult]::OK){$r=$d.FileName}\n"
        "$o.Close()\n"
        "if($r){Write-Output $r}\n"
    )
    enc = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    out = subprocess.run(["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                         capture_output=True, timeout=600, creationflags=flags)
    return out.stdout.decode("utf-8", "replace").strip().lstrip("\ufeff")


def get_file(name):
    f = ST["byname"].get(name)
    if not f:
        raise FileNotFoundError("목록에 없는 파일: " + str(name))
    return f


# ---------------------------------------------------------------- image io
def to_work(im):
    if im.mode in ("L", "RGB"):
        return im
    if im.mode == "1" or im.mode == "LA":
        return im.convert("L")
    if im.mode.startswith("I"):
        a = np.asarray(im, dtype=np.float32)
        div = 257.0 if a.max() > 255 else 1.0
        return Image.fromarray(np.clip(a / div, 0, 255).astype(np.uint8))
    return im.convert("RGB")


def read_meta(im, path):
    dpi = im.info.get("dpi")
    try:
        dpi = [round(float(dpi[0]), 2), round(float(dpi[1]), 2)] if dpi else None
    except Exception:
        dpi = None
    return {"w": im.width, "h": im.height, "mode": im.mode, "dpi": dpi, "format": im.format,
            "compression": im.info.get("compression"), "bytes": os.path.getsize(path)}


def edge_stats(im):
    """가장자리 띠 밝기 (원본 해상도, 바깥쪽부터 최대 260줄) — engine.js edgeStats 와 같음"""
    W, H = im.size
    D = max(1, min(260, min(W, H) // 4))

    def lum(box):
        a = np.asarray(im.crop(box).convert("RGB"), np.float32)
        return np.clip((a[..., 0] * 299 + a[..., 1] * 587 + a[..., 2] * 114) / 1000 + 0.5, 0, 255).astype(np.uint8)
    t = lum((0, 0, W, D))
    b = lum((0, H - D, W, H))[::-1]
    l = lum((0, 0, D, H)).T
    r = lum((W - D, 0, W, H)).T[::-1]
    return {"t": t, "b": b, "l": l, "r": r}


def trim_from(st, max_px):
    """테두리 줄만 최대 max_px 까지 (engine.js trimFrom 과 같음)"""
    o = {"l": 0, "t": 0, "r": 0, "b": 0}
    if not st or not max_px or max_px <= 0:
        return o
    for k in ("l", "t", "r", "b"):
        a = st.get(k)
        if a is None or not hasattr(a, "shape"):
            continue
        D = a.shape[0]
        mx = min(int(round(max_px)), D - 8)
        if mx <= 0:
            continue
        a = a.astype(np.int16)
        ref = float(np.sort(a[mx:min(D, mx + 30)].mean(axis=1))[len(a[mx:min(D, mx + 30)]) // 2])
        m = a[:mx].mean(axis=1)
        dev = (np.abs(a[:mx] - ref) > 50).mean(axis=1)
        hit = np.nonzero((np.abs(m - ref) > 40) | (dev > 0.25))[0]
        if len(hit):
            o[k] = int(hit[-1]) + 1
    return o


def _lbl_comps(b):
    """b: bool HxW -> list of (x0,y0,x1,y1,n) 4-connected"""
    H, W = b.shape
    seen = np.zeros_like(b)
    out = []
    ys, xs = np.nonzero(b)
    for y, x in zip(ys.tolist(), xs.tolist()):
        if seen[y, x]:
            continue
        seen[y, x] = True
        q = [(y, x)]; x0 = x1 = x; y0 = y1 = y; n = 0
        while q:
            cy, cx = q.pop(); n += 1
            if cx < x0: x0 = cx
            if cx > x1: x1 = cx
            if cy < y0: y0 = cy
            if cy > y1: y1 = cy
            for ny, nx in ((cy-1, cx), (cy+1, cx), (cy, cx-1), (cy, cx+1), (cy-1, cx-1), (cy-1, cx+1), (cy+1, cx-1), (cy+1, cx+1)):
                if 0 <= ny < H and 0 <= nx < W and b[ny, nx] and not seen[ny, nx]:
                    seen[ny, nx] = True; q.append((ny, nx))
        out.append((x0, y0, x1 + 1, y1 + 1, n))
    return out


def _lbl_merge(cs, lim):
    """한 글자가 여러 조각(7 의 가로획·세로획 등)으로 나뉜 것을 합침"""
    cs = [list(c) for c in cs]
    small = [c for c in cs if c[3] - c[1] < lim and c[2] - c[0] < lim]
    big = [tuple(c) for c in cs if not (c[3] - c[1] < lim and c[2] - c[0] < lim)]
    small.sort(key=lambda c: c[0])
    done = False
    while not done:
        done = True
        for i in range(len(small)):
            a = small[i]
            for j in range(i + 1, len(small)):
                b = small[j]
                if b[0] > a[2]:
                    break
                ov = min(a[2], b[2]) - max(a[0], b[0])
                gap = max(a[1], b[1]) - min(a[3], b[3])
                if ov >= 0.5 * min(a[2] - a[0], b[2] - b[0]) and gap <= 0.25 * max(a[3] - a[1], b[3] - b[1]) + 1:
                    a[:] = [min(a[0], b[0]), min(a[1], b[1]), max(a[2], b[2]), max(a[3], b[3]), a[4] + b[4]]
                    del small[j]; done = False; break
            if not done:
                break
    return [tuple(c) for c in small] + big

def label_rot(g):
    """라벨 번호(오른쪽 아래 4자리 숫자 도장)가 어느 모서리에 어떤 방향으로 있는지 찾아, 정면으로 보이게 돌릴 각도(시계 방향)"""
    H, W = g.shape
    M = max(W, H)
    paper = float(np.percentile(g, 90))
    thr = paper - 60
    e = max(2, round(0.012 * M))
    res = {}
    for corner, vert in (("br", False), ("tl", False), ("bl", True), ("tr", True)):
        rw, rh = round(W * 0.3), round(H * 0.3)
        x0 = W - rw if corner in ("br", "tr") else e
        x1 = W - e if corner in ("br", "tr") else rw
        y0 = H - rh if corner in ("br", "bl") else e
        y1 = H - e if corner in ("br", "bl") else rh
        reg = g[y0:y1, x0:x1] < thr
        if vert:
            reg = reg.T
        cs = _lbl_merge(_lbl_comps(reg), 0.05 * M)
        RH, RW = reg.shape
        best = None
        digs = []
        for c in cs:
            w, h = c[2] - c[0], c[3] - c[1]
            if c[0] == 0 or c[1] == 0 or c[2] == RW or c[3] == RH:
                continue
            if 0.008 * M <= h <= 0.045 * M and w >= 2 and 1.1 <= h / w <= 3.4:
                digs.append(c)
        digs.sort(key=lambda c: c[0])
        for i in range(len(digs)):
            ch = [digs[i]]
            for j in range(i + 1, len(digs)):
                a, b = ch[-1], digs[j]
                ha, hb = a[3] - a[1], b[3] - b[1]
                gap = b[0] - a[2]
                if abs((a[1] + a[3]) - (b[1] + b[3])) / 2 < 0.35 * max(ha, hb) and abs(ha - hb) < 0.25 * max(ha, hb) and -0.1 * ha <= gap <= 1.2 * ha:
                    ch.append(b)
                elif b[0] - a[2] > 1.2 * ha:
                    break
            if not 3 <= len(ch) <= 6:
                continue
            gx0 = min(c[0] for c in ch); gx1 = max(c[2] for c in ch)
            gy0 = min(c[1] for c in ch); gy1 = max(c[3] for c in ch)
            hm = gy1 - gy0
            pad = 1.5 * hm
            others = sum(1 for c in cs if c not in ch and c[4] >= 4 and 0.4 * hm <= c[3] - c[1] <= 2 * hm and c[2] - c[0] <= 4 * hm and c[2] > gx0 - pad and c[0] < gx1 + pad and c[3] > gy0 - pad and c[1] < gy1 + pad)
            if others > 1:
                continue
            hs = [c[3] - c[1] for c in ch]; ws = [c[2] - c[0] for c in ch]
            cx = [(c[0] + c[2]) / 2 for c in ch]; st = [cx[k + 1] - cx[k] for k in range(len(cx) - 1)]
            cv = lambda v: float(np.std(v) / max(1e-6, np.mean(v)))
            score = 10 - abs(len(ch) - 4) * 3 - others * 2 - cv(hs) * 10 - cv(st) * 10 - cv(ws) * 3
            if not best or score > best[0]:
                best = (round(score, 2), len(ch), (gx0, gy0, gx1, gy1))
        if best:
            res[corner] = best
    rot = {"br": 0, "tl": 180, "bl": 270, "tr": 90}
    cand = [(v[0] + (0.5 if k == 'br' else 0), k) for k, v in res.items() if v[0] >= 5]
    if not cand:
        return None, res
    cand.sort(reverse=True)
    return rot[cand[0][1]], res


def label_info(p):
    if "label" not in p:
        try:
            r, res = label_rot(p["gray"])
            p["label"] = {"rot": r, "found": sorted(res)} if r is not None else None
        except Exception:
            p["label"] = None
    return p["label"]


def trim_max(meta):
    v = fnum(CFG.get("trim_px"), 5)
    if CFG.get("trim_unit") != "mm":
        return v
    dpi = ((meta or {}).get("dpi") or [300])[0] or 300
    return round(v * float(dpi) / 25.4)


def ram_mb():
    """PC 전체 메모리(MB). 모르면 8GB 로 가정"""
    try:
        if os.name == "nt":
            import ctypes

            class MS(ctypes.Structure):
                _fields_ = [("dwLength", ctypes.c_ulong), ("dwMemoryLoad", ctypes.c_ulong),
                            ("ullTotalPhys", ctypes.c_ulonglong), ("ullAvailPhys", ctypes.c_ulonglong),
                            ("ullTotalPageFile", ctypes.c_ulonglong), ("ullAvailPageFile", ctypes.c_ulonglong),
                            ("ullTotalVirtual", ctypes.c_ulonglong), ("ullAvailVirtual", ctypes.c_ulonglong),
                            ("sullAvailExtendedVirtual", ctypes.c_ulonglong)]
            m = MS()
            m.dwLength = ctypes.sizeof(MS)
            ctypes.windll.kernel32.GlobalMemoryStatusEx(ctypes.byref(m))
            return int(m.ullTotalPhys // (1 << 20))
        return int(os.sysconf("SC_PAGE_SIZE") * os.sysconf("SC_PHYS_PAGES") // (1 << 20))
    except Exception:
        return 8192


RAM_MB = ram_mb()
# 동시에 풀어 둘 수 있는 원래 크기 이미지의 합계 (PC 메모리의 약 8%, 150MB~1GB)
MEM_BUDGET = int(max(150, min(1024, RAM_MB * 0.08))) << 20


class MemGate:
    """큰 이미지를 푸는 동안 자리를 잡아 둠 — 합계가 한도를 넘으면 앞의 것이 끝날 때까지 기다림"""
    cv = threading.Condition()
    used = 0

    def __init__(self, need):
        self.need = min(int(need), MEM_BUDGET)

    def __enter__(self):
        with MemGate.cv:
            while MemGate.used and MemGate.used + self.need > MEM_BUDGET:
                MemGate.cv.wait(1.0)
            MemGate.used += self.need
        return self

    def __exit__(self, *a):
        with MemGate.cv:
            MemGate.used -= self.need
            MemGate.cv.notify_all()


def mem_trim():
    """리눅스: 다 쓴 메모리를 운영체제에 돌려줌 (윈도는 알아서 돌려줌)"""
    try:
        if os.name != "nt":
            import ctypes
            ctypes.CDLL("libc.so.6").malloc_trim(0)
    except Exception:
        pass


def get_preview(path):
    mx = int(CFG.get("preview", 2400))
    s = sig(path)
    if s is None:
        raise FileNotFoundError(path)
    v = PREV.get((s, mx))
    if v:
        return v
    with plock(path):
        s = sig(path)
        v = PREV.get((s, mx))
        if v:
            return v
        with Image.open(path) as im:
            meta = read_meta(im, path)
            if im.format == "JPEG":
                im.draft("RGB" if im.mode not in ("L",) else "L", (mx, mx))
            need = im.size[0] * im.size[1] * (1 if im.mode in ("1", "L", "P") else 3)
            if im.format == "JPEG":
                need //= 4
            with MemGate(need):  # 큰 이미지를 한꺼번에 너무 많이 풀지 않게 (메모리 작은 PC 보호)
                im.load()
                w = to_work(im)  # 복사본을 따로 만들지 않고 그대로 줄임 (메모리 절반)
                edges = edge_stats(w)
                try:
                    w.thumbnail((mx, mx), RS.LANCZOS, reducing_gap=3.0)
                except TypeError:  # Pillow < 7
                    w.thumbnail((mx, mx), RS.LANCZOS)
        buf = io.BytesIO()
        w.save(buf, "JPEG", quality=88)
        g = w.convert("L")
        g.thumbnail((1000, 1000), RS.BILINEAR)
        v = {"jpeg": buf.getvalue(), "meta": meta, "gray": np.asarray(g, dtype=np.uint8),
             "pw": w.width, "ph": w.height, "edges": edges}
        PREV.put((s, mx), v)
        return v


FULL = LRU(3)


def get_full(path):
    """원본 해상도 그대로의 화면용 이미지 (크게 확대했을 때만 불러옴)"""
    s = sig(path)
    if s is None:
        raise FileNotFoundError(path)
    v = FULL.get(s)
    if v:
        return v
    with plock(path):
        with Image.open(path) as im:
            im.load()
            w = to_work(im)
            if w is im:
                w = im.copy()
        buf = io.BytesIO()
        w.save(buf, "JPEG", quality=92)
        v = buf.getvalue()
        FULL.put(s, v)
        return v


# ---------------------------------------------------------------- analysis
def paper_box(g):
    h, w = g.shape
    p = float(np.percentile(g, 92))
    thr = max(80.0, p * 0.6)
    b = g > thr
    ys = np.where(b.mean(axis=1) > 0.6)[0]
    xs = np.where(b.mean(axis=0) > 0.6)[0]
    if len(ys) == 0 or len(xs) == 0:
        return (0, 0, w, h), p
    return (int(xs[0]), int(ys[0]), int(xs[-1]) + 1, int(ys[-1]) + 1), p


def ink_mask(g, p):
    return g < min(p - 45.0, p * 0.75)


def content_box(mask, box):
    x0, y0, x1, y1 = box
    sub = mask[y0:y1, x0:x1]
    h, w = sub.shape
    if h < 4 or w < 4:
        return None
    ry = np.where(sub.sum(1) > max(1, w * 0.003))[0]
    cx = np.where(sub.sum(0) > max(1, h * 0.003))[0]
    if len(ry) == 0 or len(cx) == 0:
        return None
    return (x0 + int(cx[0]), y0 + int(ry[0]), x0 + int(cx[-1]) + 1, y0 + int(ry[-1]) + 1)


def inset(box, w, h, r=0.012):
    x0, y0, x1, y1 = box
    ix, iy = int(w * r), int(h * r)
    return (x0 + ix, y0 + iy, max(x0 + ix + 1, x1 - ix), max(y0 + iy + 1, y1 - iy))


def estimate_skew(mask):
    """투영 프로파일 방식. 반환값은 '시계방향 보정 각도'(도)와 신뢰도."""
    h, w = mask.shape
    if h < 20 or w < 20 or mask.sum() < 200:
        return 0.0, 0.0
    im = Image.fromarray(mask.astype(np.uint8) * 255)
    sc = 700.0 / max(h, w)
    if sc < 1:
        im = im.resize((max(8, int(w * sc)), max(8, int(h * sc))), RS.BILINEAR)

    def score(a):
        r = im.rotate(a, resample=RS.BILINEAR, expand=False, fillcolor=0) if a else im
        d = np.diff(np.asarray(r, np.float32).sum(1))
        return float((d * d).sum())

    base = score(0.0)
    best, bs = 0.0, base
    for a in np.arange(-5.0, 5.001, 0.25):
        s = score(float(a))
        if s > bs:
            best, bs = float(a), s
    c = best
    for a in np.arange(c - 0.25, c + 0.2501, 0.05):
        s = score(float(a))
        if s > bs:
            best, bs = float(a), s
    conf = (bs - base) / base if base > 0 else 0.0
    return round(-best, 2), round(conf, 4)


WHITE = 245


def frame_angle(g):
    """흰 쐐기(이미지를 돌릴 때 생긴 빈 모서리)의 경계선 각도. 없으면 None. index.html analyze.js frameAngle 과 같은 계산"""
    h, w = g.shape
    border = np.concatenate([g[0, :], g[-1, :], g[:, 0], g[:, -1]])
    if (border >= 248).mean() < 0.03 or (g < WHITE).mean() < 0.5:
        return None
    m = g < WHITE
    wt = ~m
    e = np.zeros_like(m)
    e[1:-1, 1:-1] = m[1:-1, 1:-1] & (wt[1:-1, :-2] | wt[1:-1, 2:] | wt[:-2, 1:-1] | wt[2:, 1:-1])
    e[:3, :] = e[-3:, :] = False
    e[:, :3] = e[:, -3:] = False
    ys, xs = np.nonzero(e)
    if len(xs) < 80:
        return None
    k = max(1, len(xs) // 8000)
    xs, ys = xs[::k].astype(np.float64), ys[::k].astype(np.float64)
    off = w + h + 2

    def score(deg):
        t = np.radians(deg)
        c, s_ = np.cos(t), np.sin(t)
        hx = np.bincount((np.floor(xs * c - ys * s_ + 0.5)).astype(np.int64) + off)
        hy = np.bincount((np.floor(xs * s_ + ys * c + 0.5)).astype(np.int64) + off)
        return float((hx.astype(np.float64) ** 2).sum() + (hy.astype(np.float64) ** 2).sum())

    base = score(0.0)
    best, bs = 0.0, base
    for kk in range(-80, 81):
        a = kk * 0.25
        v = score(a)
        if v > bs:
            best, bs = a, v
    c0 = best
    for kk in range(-12, 13):
        a = c0 + kk * 0.02
        v = score(a)
        if v > bs:
            best, bs = a, v
    conf = (bs - base) / base if base > 0 else 0.0
    return (0.0 if abs(best) < 0.05 else round(best, 2)), round(conf, 4)


def max_inner_rect(a):
    """흰 바탕이 하나도 안 들어가는 가장 큰 가로·세로 사각형"""
    H, W = a.shape
    m = a < WHITE
    anyr = m.any(1)
    L = np.where(anyr, m.argmax(1), W)
    R = np.where(anyr, W - 1 - m[:, ::-1].argmax(1), -1)
    best, ba = (0, 0, W, H), 0
    for t in range(H):
        if R[t] - L[t] < 2:
            continue
        mL = np.maximum.accumulate(L[t:])
        mR = np.minimum.accumulate(R[t:])
        wd = mR - mL
        ok = wd >= 2
        if not ok.any():
            continue
        n = int(np.argmin(ok)) if not ok.all() else len(ok)
        ar = (np.arange(n) + 1) * (wd[:n] + 1)
        b = int(np.argmax(ar))
        if ar[b] > ba:
            ba = int(ar[b])
            best = (int(mL[b]), t, int(mR[b]) + 1, t + b + 1)
    d = 2
    return (best[0] + d, best[1] + d, best[2] - d, best[3] - d)



def frac(b, w, h):
    return [b[0] / w, b[1] / h, (b[2] - b[0]) / w, (b[3] - b[1]) / h]


def analyze(g, meta):
    h, w = g.shape
    gf = g.astype(np.float32)
    pb, p = paper_box(gf)
    mask = ink_mask(gf, p)
    inner = inset(pb, w, h)
    cb = content_box(mask, inner)
    sub = mask[inner[1]:inner[3], inner[0]:inner[2]]
    ink = float(sub.mean()) if sub.size else 0.0
    skew, conf = estimate_skew(sub) if CFG.get("skew_est") else (0.0, 0.0)  # 미세 기울기는 자동으로 고치지 않으므로 기본은 계산 생략 (분석 시간의 대부분)
    band = max(2, int(min(h, w) * 0.006))
    strips = {"l": (slice(None), slice(1, band + 1)), "r": (slice(None), slice(w - band - 1, w - 1)),
              "t": (slice(1, band + 1), slice(None)), "b": (slice(h - band - 1, h - 1), slice(None))}
    dark = {k: bool(gf[s].mean() < 100) for k, s in strips.items()}
    touch = {k: bool((not dark[k]) and mask[s].mean() > 0.02) for k, s in strips.items()}
    res = {"skew": skew, "skew_conf": conf, "paper": frac(pb, w, h),
           "content": frac(cb, w, h) if cb else None, "ink": round(ink, 5),
           "levels": [round(float(np.percentile(gf, 0.5))), round(float(np.percentile(gf, 99.5)))],
           "dark": dark, "touch": touch}

    # 자동 보정안: 기울기 보정 후 다시 측정 (분수 좌표 = 회전된 이미지 기준)
    # 사진처럼 흰 쐐기(회전 흔적)가 있으면: 쐐기 경계선 각도로 기울기, 쐐기가 안 남는 가장 큰 사각형으로 크롭
    fr = frame_angle(g)
    frame = fr is not None
    tilt = fr[0] if frame else (skew if (abs(skew) >= 0.05 and conf > 0.01) else 0.0)
    if frame:
        res["skew"], res["skew_conf"], res["frame"] = fr[0], fr[1], True
    gi = Image.fromarray(g)
    edge = np.concatenate([g[0, :], g[-1, :], g[:, 0], g[:, -1]])
    bg = 255 if frame else int(np.median(edge))  # 스캐너 배경색으로 채워야 용지 경계가 정확히 잡힘
    gr = gi.rotate(-tilt, resample=RS.BILINEAR, expand=True, fillcolor=bg) if tilt else gi
    a = np.asarray(gr, np.float32)
    H, W = a.shape
    if frame:
        qb, p2 = max_inner_rect(a), float(np.percentile(a, 50))
    else:
        qb, p2 = paper_box(a)
    cb2 = content_box(ink_mask(a, p2), inset(qb, W, H, 0 if frame else 0.012))
    full_paper = (not frame) and (qb[2] - qb[0]) > W * 0.995 and (qb[3] - qb[1]) > H * 0.995
    # 용지 가장자리의 경계선(1~2px 그림자)을 피하도록 살짝 안쪽으로
    px, py = max(1, int(W * 0.003)), max(1, int(H * 0.003))
    qbi = (qb[0] + px, qb[1] + py, qb[2] - px, qb[3] - py) if not (full_paper or frame) else qb
    crop_paper = frac(qbi, W, H)
    if full_paper:
        # 잘라낼 테두리가 없으면 기울기만 보정하고 원래 크기 유지
        crop_paper = [(W - w) / 2 / W, (H - h) / 2 / H, w / W, h / H] if tilt else None
    dpi = ((meta.get("dpi") or [300])[0]) or 300
    m = float(CFG.get("margin_mm", 10)) / 25.4 * dpi * (w / max(1, meta["w"]))
    crop_content = None
    if cb2:
        # 여백은 용지 안쪽까지만 (스캐너 배경이 들어오지 않게)
        lim = qbi if not full_paper else (-10 ** 6, -10 ** 6, 10 ** 6, 10 ** 6)
        x0, y0 = max(cb2[0] - m, lim[0]), max(cb2[1] - m, lim[1])
        x1, y1 = min(cb2[2] + m, lim[2]), min(cb2[3] + m, lim[3])
        crop_content = [x0 / W, y0 / H, (x1 - x0) / W, (y1 - y0) / H]
    # 용지 경계 + 좌우 여백 균등: 내용 기준으로 좌우 여백을 작은 쪽에 맞춤 (용지 밖으로 나가지 않음)
    base_r = [crop_paper[0] * W, crop_paper[1] * H, (crop_paper[0] + crop_paper[2]) * W,
              (crop_paper[1] + crop_paper[3]) * H] if crop_paper else [0, 0, W, H]
    crop_balance = None
    if cb2 and cb2[0] >= base_r[0] and cb2[2] <= base_r[2]:
        mm = min(cb2[0] - base_r[0], base_r[2] - cb2[2])
        crop_balance = [(cb2[0] - mm) / W, base_r[1] / H, (cb2[2] - cb2[0] + 2 * mm) / W, (base_r[3] - base_r[1]) / H]
    res["auto"] = {"tilt": round(tilt, 2), "crop_paper": crop_paper, "crop_balance": crop_balance,
                   "crop_content": crop_content}

    # 자동 보정 결과물 기준 검사 (현재 자동 보정 방식으로)
    mode = CFG.get("auto_mode", "balance")
    chosen = {"paper": crop_paper, "balance": crop_balance or crop_paper,
              "content": crop_content or crop_paper}.get(mode, crop_paper)
    r = [chosen[0] * W, chosen[1] * H, (chosen[0] + chosen[2]) * W, (chosen[1] + chosen[3]) * H] if chosen else [0, 0, W, H]
    aq = []

    def add(code, level, msg, fix=None):
        aq.append({"code": code, "level": level, "msg": msg, "fix": fix})

    if ink < 0.0006:
        add("blank", "info", "빈 페이지 의심")
    else:
        if abs(tilt) >= 2:
            add("bigtilt", "warn", "기울기 %+.1f° 보정됨 · 회전 확인" % tilt)
        if cb2:
            tol_x, tol_y = W * 0.004, H * 0.004
            sides = [k for k, cond in (("좌", cb2[0] - r[0] < tol_x), ("우", r[2] - cb2[2] < tol_x),
                                      ("상", cb2[1] - r[1] < tol_y), ("하", r[3] - cb2[3] < tol_y)) if cond]
            if sides:
                add("touch", "error", "내용이 가장자리에 닿음 (" + "·".join(sides) + ") · 잘림 확인",
                    "mode_paper" if mode != "paper" else "crop")
        rx0, ry0 = int(max(0, r[0])), int(max(0, r[1]))
        rx1, ry1 = int(min(W, r[2])), int(min(H, r[3]))
        if rx1 - rx0 > 20 and ry1 - ry0 > 20:
            sub2 = a[ry0:ry1, rx0:rx1]
            b2 = max(2, int(min(sub2.shape) * 0.006))
            dk = [k for k, st in (("좌", sub2[:, 1:b2 + 1]), ("우", sub2[:, -b2 - 1:-1]),
                                   ("상", sub2[1:b2 + 1, :]), ("하", sub2[-b2 - 1:-1, :])) if st.mean() < 100]
            if dk:
                add("dark", "warn", "검은 테두리 남음 (" + "·".join(dk) + ")", "crop")
        if full_paper and any(dark.values()):
            add("nopaper", "warn", "용지 경계를 찾지 못함 · 크롭 확인", "crop")
        if W > H * 1.05:
            add("landscape", "info", "가로 문서 · 방향 확인")
    res["auto"]["qc"] = aq
    if cb:
        mm = (cb[0] + (w - cb[2])) / 2.0
        res["balance"] = [(cb[0] - mm) / w, 0.0, (cb[2] - cb[0] + 2 * mm) / w, 1.0]
    return res


SIDE_KO = {"l": "좌", "r": "우", "t": "상", "b": "하"}


def qc(hp, orig):
    W = []

    def add(code, level, msg, fix=None):
        W.append({"code": code, "level": level, "msg": msg, "fix": fix})

    if not hp:
        add("missing", "warn", "보정본(HP) 파일 없음 · 원본 기준으로 표시 중", "orig_auto")
        return W
    an, m = hp["an"], hp["meta"]
    if abs(an["skew"]) >= float(CFG.get("skew_warn", 0.3)) and an["skew_conf"] > 0.02:
        add("skew", "warn", "기울기 %+.2f° 감지" % an["skew"], "tilt")
    dk = [SIDE_KO[k] for k, v in an["dark"].items() if v]
    if dk:
        add("dark", "warn", "검은 테두리 남음 (" + "·".join(dk) + ")", "paper")
    tc = [SIDE_KO[k] for k, v in an["touch"].items() if v]
    if tc:
        add("touch", "error", "내용이 가장자리에 닿음 (" + "·".join(tc) + ") · 잘림 의심", "orig_auto")
    c = an.get("content")
    if c:
        lm, rm = c[0], 1 - c[0] - c[2]
        mx = max(lm, rm)
        if mx > 0.02 and abs(lm - rm) > 0.03 and min(lm, rm) / mx < 0.6:
            add("margin", "info", "좌우 여백 불균형 L %.1f%% / R %.1f%%" % (lm * 100, rm * 100), "balance")
    if orig:
        om = orig["meta"]
        if (m["w"] > m["h"]) != (om["w"] > om["h"]):
            add("orient", "warn", "가로·세로 방향이 원본과 다름 · 회전 확인")
        else:
            ratio = (m["w"] * m["h"]) / float(max(1, om["w"] * om["h"]))
            if ratio < 0.75:
                if CFG.get("auto_mode") == "content":
                    add("small", "info", "원본 대비 면적 %d%% (내용+여백 모드)" % round(ratio * 100))
                else:
                    add("small", "error", "원본 대비 면적 %d%% · 크롭 과다 의심" % round(ratio * 100), "orig_auto")
            elif ratio > 1.03:
                add("big", "info", "원본보다 큼 (%d%%)" % round(ratio * 100))
        if m.get("dpi") and om.get("dpi") and abs(m["dpi"][0] - om["dpi"][0]) > 1:
            add("dpi", "info", "DPI 다름 · HP %d / 원본 %d" % (m["dpi"][0], om["dpi"][0]))
        if m["mode"] != om["mode"]:
            add("mode", "info", "색상 모드 다름 · HP %s / 원본 %s" % (m["mode"], om["mode"]))
    if an["ink"] < 0.0006:
        add("blank", "info", "빈 페이지 의심")
    return W


INFL, INFL_LOCK = {}, threading.Lock()  # 지금 풀고 있는 파일


def get_info(name, cur=False, bg=False):
    f = get_file(name)
    sh, so = sig(f["hp"]), sig(f["orig"])
    key = (sh, so, CFG.get("preview"), CFG.get("margin_mm"), CFG.get("skew_warn"), CFG.get("auto_mode"), CFG.get("trim_px"), CFG.get("trim_unit"), CFG.get("label_rot"))
    v = INFO.get(key)
    if v is None:  # 같은 파일을 미리 읽기가 이미 풀고 있으면 기다렸다가 그 결과를 씀 (두 번 풀지 않게)
        with INFL_LOCK:
            ev = INFL.get(key)
            mine = ev is None
            if mine:
                ev = INFL[key] = threading.Event()
        if not mine:
            PF["want"].add(key)  # 미리 읽기가 풀고 있는 바로 그 파일을 화면이 기다림 → 그 작업은 양보하지 말고 계속
            try:
                ev.wait(120)
            finally:
                PF["want"].discard(key)
            v = INFO.get(key)
            mine = v is None
    if v is None:
      try:
        v = {"name": name, "hp": None, "orig": None}
        # 원본·보정본을 동시에 읽어 압축 풀기 (큰 TIF 는 이 단계가 대부분이라 기다림이 거의 절반)
        if bg:  # 미리 읽기: 한 면씩 차례로, 화면 쪽 요청이 오면 사이사이 양보 (화면이 굼떠지지 않게)
            class _Now:
                def __init__(self, path):
                    bg_yield(key)
                    self.v = get_preview(path)

                def result(self):
                    return self.v
            futs = {}
            for side, s in (("hp", sh), ("orig", so)):
                if s:
                    futs[side] = _Now(f[side])
            bg_yield(key)
        else:
            futs = {side: DEC.submit(get_preview, f[side]) for side, s in (("hp", sh), ("orig", so)) if s}
        for side, s in (("hp", sh), ("orig", so)):
            if s:
                p = futs[side].result()
                v[side] = {"meta": p["meta"], "pw": p["pw"], "ph": p["ph"],
                           "an": analyze(p["gray"], p["meta"]), "v": "%d_%d" % (s[1], s[2]),
                           "trim": trim_from(p.get("edges"), trim_max(p["meta"])),
                           "label": label_info(p)}
        v["qc"] = qc(v["hp"], v["orig"])
        INFO.put(key, v)
      finally:
        with INFL_LOCK:
            e = INFL.pop(key, None)
        if e:
            e.set()
    out = dict(v)
    out["status"] = (ST["sess"] or {}).get("statuses", {}).get(name, "")
    out["backup"] = bool(f["hp"]) and os.path.exists(backup_path(f["hp"]))
    if cur:
        set_status(name, None, last=True)
    return out


PF = {"tok": 0, "fg": 0, "want": set()}  # tok: 마지막 미리 읽기 요청 번호 (넘기면 이전 요청은 멈춤) · fg: 지금 화면에 띄우는 중인 요청 수


def read_ahead(names, gen, tok):
    """네트워크 드라이브 대비: 다음 파일들을 먼저 읽어 두기만 (압축은 안 풂 → 윈도 파일 캐시에 올라가 나중에 빨리 열림)"""
    for n in names:
        if gen != ST["gen"] or tok != PF["tok"]:
            return
        f = ST["byname"].get(n) if ST.get("byname") else None
        for path in ((f or {}).get("hp"), (f or {}).get("orig")):
            if not path:
                continue
            try:
                with open(path, "rb") as fh:
                    while fh.read(4 << 20):
                        if tok != PF["tok"]:
                            return
            except OSError:
                pass


def bg_yield(key=None):
    """화면 쪽 요청(지금 장 불러오기·확대)이 진행 중이면 끝날 때까지 잠깐 기다림 (최대 5초)
    단, 화면이 기다리는 게 바로 이 파일이면 기다리지 않음"""
    for _ in range(100):
        if PF["fg"] <= 0 or (key is not None and key in PF["want"]):
            return
        time.sleep(0.05)


def low_priority():
    """이 스레드를 낮은 우선순위로 (윈도) — 미리 읽기가 화면 반응을 밀어내지 않게"""
    try:
        if os.name == "nt":
            import ctypes
            k = ctypes.windll.kernel32
            k.SetThreadPriority(k.GetCurrentThread(), -1)  # THREAD_PRIORITY_BELOW_NORMAL
    except Exception:
        pass


def prefetch(names, gen, tok):
    """다음 파일들을 미리 풀어 둠
    바로 다음 2장은 여러 장 동시에(코어가 많으면) 서둘러 풀고, 그 뒤 장들은 한 장씩 천천히 —
    미리 읽기 장수를 크게 잡아도 PC가 계속 바쁘지 않게"""
    names = list(names)
    threading.Thread(target=read_ahead, args=(names, gen, tok), daemon=True).start()

    def run(part, lanes, gentle):
        it, lock = iter(part), threading.Lock()

        def lane():
            if gentle:
                low_priority()
            while True:
                with lock:
                    n = next(it, None)
                if n is None or gen != ST["gen"] or tok != PF["tok"]:
                    return
                bg_yield()
                if tok != PF["tok"]:
                    return
                try:
                    get_info(n, bg=gentle)
                except Exception:
                    pass
        ts = [threading.Thread(target=lane, daemon=True) for _ in range(lanes)]
        for t in ts:
            t.start()
        for t in ts:
            t.join()
    run(names[:2], min(2, PF_LANES), False)  # 바로 다음 2장: 원본·보정본 동시에 서둘러
    run(names[2:], 1, True)                  # 그 뒤: 한 면씩 천천히, 화면 쪽에 양보하면서
    mem_trim()


# ---------------------------------------------------------------- edits / save
def fnum(x, d=0.0):
    try:
        return float(x)
    except Exception:
        return d


def _curve_def(p):
    return not p or (len(p) == 2 and list(p[0]) == [0, 0] and list(p[1]) == [255, 255])


def _cb_def(b):
    return not b or all(not b.get(k) or all(fnum(v) == 0 for v in b[k]) for k in ("s", "m", "h"))


def color_default(c):
    cv = c.get("cv") or {}
    return (not c.get("gray") and fnum(c.get("bright")) == 0 and fnum(c.get("contrast")) == 0
            and fnum(c.get("gamma"), 1) == 1 and fnum(c.get("black")) == 0 and fnum(c.get("white"), 255) == 255
            and all(_curve_def(cv.get(k)) for k in ("rgb", "r", "g", "b")) and _cb_def(c.get("cb")))


def is_default(e):
    z = e.get("resize") or {}
    return (int(fnum(e.get("rot"))) % 360 == 0 and abs(fnum(e.get("tilt"))) < 1e-6 and not e.get("crop")
            and not e.get("erases") and not e.get("paints") and color_default(e.get("color") or {})
            and all(color_default(l.get("color") or {}) for l in (e.get("locals") or []))
            and (z.get("mode", "none") == "none" or (z.get("mode") == "percent" and fnum(z.get("value"), 100) == 100)))


def curve_lut(pts):
    """곡선: 단조 3차 보간(Fritsch–Carlson) — index.html curveLut 과 같은 계산"""
    P = sorted([(min(255.0, max(0.0, fnum(a))), min(255.0, max(0.0, fnum(b)))) for a, b in (pts or [[0, 0], [255, 255]])])
    P = [p for i, p in enumerate(P) if i == 0 or p[0] > P[i - 1][0]]
    n = len(P)
    if n < 2:
        return np.arange(256, dtype=np.float64)
    d = [(P[i + 1][1] - P[i][1]) / (P[i + 1][0] - P[i][0]) for i in range(n - 1)]
    m = [0.0] * n
    m[0], m[-1] = d[0], d[-1]
    for i in range(1, n - 1):
        m[i] = 0.0 if d[i - 1] * d[i] <= 0 else (d[i - 1] + d[i]) / 2
    for i in range(n - 1):
        if d[i] == 0:
            m[i] = m[i + 1] = 0.0
            continue
        a, b = m[i] / d[i], m[i + 1] / d[i]
        q = a * a + b * b
        if q > 9:
            t = 3 / np.sqrt(q)
            m[i], m[i + 1] = t * a * d[i], t * b * d[i]
    out = np.zeros(256)
    k = 0
    for v in range(256):
        if v <= P[0][0]:
            out[v] = P[0][1]
            continue
        if v >= P[-1][0]:
            out[v] = P[-1][1]
            continue
        while k < n - 2 and v > P[k + 1][0]:
            k += 1
        x0, x1 = P[k][0], P[k + 1][0]
        h = x1 - x0
        t = (v - x0) / h
        t2, t3 = t * t, t * t * t
        out[v] = ((2 * t3 - 3 * t2 + 1) * P[k][1] + (t3 - 2 * t2 + t) * h * m[k]
                  + (-2 * t3 + 3 * t2) * P[k + 1][1] + (t3 - t2) * h * m[k + 1])
    return out


def _cb_offset(cb, ch, v):
    if not cb:
        return 0.0
    ws, wh, wm = max(0.0, 1 - v / 128.0), max(0.0, (v - 128) / 127.0), 1 - abs(v - 128) / 128.0
    g = lambda k: fnum((cb.get(k) or [0, 0, 0])[ch])
    return 0.5 * (g("s") * ws + g("m") * wm + g("h") * wh)


def build_luts(c, mode):
    """밝기·대비·감마·레벨 → RGB 곡선 → 채널 곡선 → 색 균형. 흑백(L)은 RGB 곡선까지만."""
    base = build_lut(c)
    cv = c.get("cv") or {}
    M = curve_lut(cv.get("rgb"))
    rgb = mode == "RGB"
    out = []
    for ch in (range(3) if rgb else range(1)):
        C = curve_lut(cv.get("rgb"[ch])) if rgb else None
        lut = []
        for v in range(256):
            x = M[int(round(min(255, max(0, base[v]))))]
            if rgb:
                x = C[int(round(min(255, max(0, x))))]
                x += _cb_offset(c.get("cb"), ch, x)
            lut.append(int(np.floor(min(255.0, max(0.0, x)) + 0.5)))
        out += lut
    return out


def build_lut(c):
    b, wv = fnum(c.get("black")), fnum(c.get("white"), 255)
    gm = fnum(c.get("gamma"), 1) or 1
    ct, br = fnum(c.get("contrast")), fnum(c.get("bright"))
    v = np.arange(256, dtype=np.float64)
    x = np.clip((v - b) / max(1.0, wv - b), 0, 1) ** (1.0 / gm)
    x = (x - 0.5) * (1 + ct / 100.0) + 0.5 + br / 100.0
    return [int(t) for t in np.clip(np.floor(np.clip(x, 0, 1) * 255 + 0.5), 0, 255)]


# ---------------------------------------------------------------- paint strokes
def _box(a, r, ax):
    pad = [(0, 0)] * a.ndim
    pad[ax] = (r + 1, r)
    c = np.cumsum(np.pad(a, pad, mode="edge"), axis=ax, dtype=np.float64)
    n = a.shape[ax]
    hi = np.take(c, np.arange(2 * r + 1, 2 * r + 1 + n), axis=ax)
    lo = np.take(c, np.arange(0, n), axis=ax)
    return ((hi - lo) / (2 * r + 1)).astype(np.float32)


def _blur(a, sigma):
    """가우시안 근사(박스 블러 3회). 화면의 CSS blur(sigma)와 같은 크기."""
    if sigma < 0.4:
        return a
    r = max(1, int(round((np.sqrt(12 * sigma * sigma / 3 + 1) - 1) / 2)))
    for _ in range(3):
        a = _box(a, r, 0)
        a = _box(a, r, 1)
    return a


def _stroke_mask(w, h, pts, r):
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    if len(pts) > 1:
        d.line(pts, fill=255, width=max(1, int(round(r * 2))), joint="curve")
    for x, y in pts:
        d.ellipse([x - r, y - r, x + r, y + r], fill=255)
    return np.asarray(m, np.float32) / 255.0


def _hex(c, gray):
    c = (c or "#000000").lstrip("#")
    try:
        rgb = [int(c[i:i + 2], 16) for i in (0, 2, 4)]
    except Exception:
        rgb = [0, 0, 0]
    return np.array([0.299 * rgb[0] + 0.587 * rgb[1] + 0.114 * rgb[2]] if gray else rgb, np.float32)


def _paper_keep(reg, hard):
    """힐링 참조 영역: 칠하지 않은 주변 중 종이색(밝은 60% 기준 -40 이상)만. 글자·얼룩은 제외."""
    lum = reg[..., 0] if reg.shape[2] == 1 else (reg[..., 0] * 299 + reg[..., 1] * 587 + reg[..., 2] * 114) / 1000
    ring = hard < 0.5
    if not ring.any():
        return 1 - hard
    thr = np.percentile(lum[ring], 60) - 40
    keep = (ring & (lum >= thr)).astype(np.float32)
    return keep if keep.sum() > ring.sum() * 0.05 else (1 - hard)


def _sel_mask(sel, W, H, x0, y0, w, h):
    m = Image.new("L", (w, h), 0)
    d = ImageDraw.Draw(m)
    x, y = fnum(sel.get("x")) * W - x0, fnum(sel.get("y")) * H - y0
    sw, sh = fnum(sel.get("w")) * W, fnum(sel.get("h")) * H
    box = [min(x, x + sw), min(y, y + sh), max(x, x + sw), max(y, y + sh)]
    if sel.get("shape") == "poly" and len(sel.get("pts") or []) >= 3:
        d.polygon([(fnum(a) * W - x0, fnum(b) * H - y0) for a, b in sel["pts"]], fill=255)
    else:
        (d.ellipse if sel.get("shape") == "ellipse" else d.rectangle)(box, fill=255)
    a = np.asarray(m, np.float32) / 255.0
    return 1 - a if sel.get("inv") else a


def _sel_box(sel, W, H):
    if sel.get("inv"):
        return 0, 0, W, H
    x, y, w, h = (fnum(sel.get(k)) for k in ("x", "y", "w", "h"))
    return (int(max(0, np.floor(min(x, x + w) * W))), int(max(0, np.floor(min(y, y + h) * H))),
            int(min(W, np.ceil(max(x, x + w) * W))), int(min(H, np.ceil(max(y, y + h) * H))))


def apply_local(im, L):
    sel, c = L.get("sel"), L.get("color") or {}
    if not sel or color_default(c):
        return im
    W, H = im.size
    x0, y0, x1, y1 = _sel_box(sel, W, H)
    if x1 - x0 < 1 or y1 - y0 < 1:
        return im
    reg = im.crop((x0, y0, x1, y1))
    adj = reg
    if c.get("gray") and adj.mode == "RGB":
        adj = adj.convert("L").convert("RGB")
    if not color_default(dict(c, gray=False)):
        adj = adj.point(build_luts(c, adj.mode))
    mask = Image.fromarray((_sel_mask(sel, W, H, x0, y0, x1 - x0, y1 - y0) * 255 + 0.5).astype(np.uint8))
    im.paste(Image.composite(adj, reg, mask), (x0, y0))
    return im


def _flood_mask(a, sx, sy, tol):
    """페인트통 (index.html floodMask 와 같음): 시작점과 각 채널 차이가 tol 이하이고 4방향으로 이어진 곳"""
    from bisect import bisect_left, bisect_right
    H, W = a.shape[:2]
    if a.ndim == 2:
        ok = np.abs(a.astype(np.int16) - int(a[sy, sx])) <= tol
    else:
        ok = np.ones((H, W), bool)
        for ch in range(min(3, a.shape[2])):
            ok &= np.abs(a[..., ch].astype(np.int16) - int(a[sy, sx, ch])) <= tol
    pad = np.zeros((H, 1), np.int8)
    d = np.diff(np.concatenate([pad, ok.astype(np.int8), pad], axis=1), axis=1)
    ys, xs = np.nonzero(d == 1)
    ye, xe = np.nonzero(d == -1)
    idx = np.concatenate([[0], np.cumsum(np.bincount(ys, minlength=H))])
    S = [xs[idx[y]:idx[y + 1]].tolist() for y in range(H)]
    E = [xe[idx[y]:idx[y + 1]].tolist() for y in range(H)]
    out = np.zeros((H, W), bool)
    k0 = bisect_right(S[sy], sx) - 1
    if k0 < 0 or E[sy][k0] <= sx:
        return out
    seen = {(sy, k0)}
    todo = [(sy, k0)]
    while todo:
        y, k = todo.pop()
        x0, x1 = S[y][k], E[y][k]
        out[y, x0:x1] = True
        for ny in (y - 1, y + 1):
            if 0 <= ny < H:
                for j in range(bisect_right(E[ny], x0), bisect_left(S[ny], x1)):
                    if (ny, j) not in seen:
                        seen.add((ny, j))
                        todo.append((ny, j))
    return out


def apply_paints(im, paints, k=1.0):
    """화면(index.html applyPaint)과 같은 규칙: 힐링=주변 배경 평균으로 채움, 도장=오프셋 복제, 브러시/펜=색칠."""
    W, H = im.size
    gray = im.mode == "L"
    for p in paints or []:
        t = p.get("t")
        sel = p.get("sel")
        if t == "bucket":
            q = (p.get("pts") or [None])[0]
            if not q:
                continue
            sx, sy = int(np.floor(fnum(q[0]) * W)), int(np.floor(fnum(q[1]) * H))
            if not (0 <= sx < W and 0 <= sy < H):
                continue
            arr = np.asarray(im)
            m = _flood_mask(arr, sx, sy, int(fnum(p.get("tol"), 32)))
            if sel:
                m &= _sel_mask(sel, W, H, 0, 0, W, H) > 0.5
            if m.any():
                arr = arr.copy()
                v = np.clip(np.round(_hex(p.get("c") or "#ffffff", gray)), 0, 255).astype(np.uint8)
                arr[m] = v[0] if gray else v
                im = Image.fromarray(arr)
            continue
        if t == "fill":
            if not sel:
                continue
            x0, y0, x1, y1 = _sel_box(sel, W, H)
            if x1 - x0 < 1 or y1 - y0 < 1:
                continue
            reg = np.asarray(im.crop((x0, y0, x1, y1)), np.float32)
            if gray:
                reg = reg[..., None]
            m = _sel_mask(sel, W, H, x0, y0, x1 - x0, y1 - y0)[..., None]
            out = np.clip(reg * (1 - m) + _hex(p.get("c") or "#ffffff", gray) * m + 0.5, 0, 255).astype(np.uint8)
            im.paste(Image.fromarray(out[..., 0] if gray else out), (x0, y0))
            continue
        pts = [(fnum(a) * W, fnum(b) * H) for a, b in (p.get("pts") or [])]
        if not pts:
            continue
        r = max(0.5, fnum(p.get("sz"), 10) * k / 2.0)
        soft = r * (1 - fnum(p.get("hd"), 80) / 100.0) if t in ("brush", "erase") else (0.0 if t == "pen" else r * 0.3)
        mg = (r * 3 if t == "heal" else soft * 2) + r + 2
        x0 = int(max(0, np.floor(min(x for x, _ in pts) - mg)))
        y0 = int(max(0, np.floor(min(y for _, y in pts) - mg)))
        x1 = int(min(W, np.ceil(max(x for x, _ in pts) + mg)))
        y1 = int(min(H, np.ceil(max(y for _, y in pts) + mg)))
        if x1 - x0 < 1 or y1 - y0 < 1:
            continue
        w, h = x1 - x0, y1 - y0
        loc = [(x - x0, y - y0) for x, y in pts]
        reg = np.asarray(im.crop((x0, y0, x1, y1)), np.float32)
        if gray:
            reg = reg[..., None]
        selm = _sel_mask(sel, W, H, x0, y0, w, h)[..., None] if sel else 1.0
        if t in ("brush", "pen", "erase"):  # 지우개 = 흰색 브러시
            op = 1.0 if t == "erase" else fnum(p.get("op"), 100) / 100.0
            m = _blur(_stroke_mask(w, h, loc, r), soft) * op
            m = m[..., None] * selm
            out = reg * (1 - m) + _hex("#ffffff" if t == "erase" else p.get("c"), gray) * m
        elif t == "stamp":
            dx, dy = int(round(fnum(p.get("dx")) * k)), int(round(fnum(p.get("dy")) * k))
            src = np.asarray(im.crop((x0 + dx, y0 + dy, x1 + dx, y1 + dy)), np.float32)
            if gray:
                src = src[..., None]
            m = _blur(_stroke_mask(w, h, loc, r), soft)[..., None] * selm
            out = reg * (1 - m) + src * m
        elif t == "heal":
            hard = _stroke_mask(w, h, loc, r)
            keep = _paper_keep(reg, hard)[..., None]
            fill = _blur(reg * keep, r) / np.maximum(_blur(keep, r), 1e-4)
            m = _blur(hard, r * 0.25)[..., None] * selm
            out = reg * (1 - m) + fill * m
        else:
            continue
        out = np.clip(out + 0.5, 0, 255).astype(np.uint8)
        im.paste(Image.fromarray(out[..., 0] if gray else out), (x0, y0))
    return im


def apply_edits(im, e, k=1.0):
    im = to_work(im)
    white = 255 if im.mode == "L" else (255, 255, 255)
    q, t = int(fnum(e.get("rot"))) % 360, fnum(e.get("tilt"))
    if abs(t) < 1e-6:
        if q == 90:
            im = im.transpose(TP.ROTATE_270)
        elif q == 180:
            im = im.transpose(TP.ROTATE_180)
        elif q == 270:
            im = im.transpose(TP.ROTATE_90)
    else:
        im = im.rotate(-(q + t), resample=RS.BICUBIC, expand=True, fillcolor=white)
    W, H = im.size
    if e.get("erases"):
        dr = ImageDraw.Draw(im)
        for r in e["erases"]:
            x0, y0 = round(fnum(r["x"]) * W), round(fnum(r["y"]) * H)
            x1, y1 = round((fnum(r["x"]) + fnum(r["w"])) * W), round((fnum(r["y"]) + fnum(r["h"])) * H)
            if x1 > x0 and y1 > y0:
                dr.rectangle([x0, y0, x1 - 1, y1 - 1], fill=white)
    c = e.get("color") or {}
    if c.get("gray") and im.mode == "RGB":
        im = im.convert("L").convert("RGB")
    if not color_default(dict(c, gray=False)):
        im = im.point(build_luts(c, im.mode))
    for L in e.get("locals") or []:  # 선택 영역 색 보정
        im = apply_local(im, L)
    if e.get("paints"):
        im = apply_paints(im, e["paints"], k)
    cr = e.get("crop")
    if isinstance(cr, (list, tuple)) and len(cr) == 4:
        cr = dict(zip("xywh", cr))
    if cr:
        x, y = round(fnum(cr["x"]) * W), round(fnum(cr["y"]) * H)
        cw, ch = max(1, round(fnum(cr["w"]) * W)), max(1, round(fnum(cr["h"]) * H))
        if x >= 0 and y >= 0 and x + cw <= W and y + ch <= H:
            im = im.crop((x, y, x + cw, y + ch))
        else:
            cv = Image.new(im.mode, (cw, ch), white)
            sx0, sy0, sx1, sy1 = max(0, x), max(0, y), min(W, x + cw), min(H, y + ch)
            if sx1 > sx0 and sy1 > sy0:
                cv.paste(im.crop((sx0, sy0, sx1, sy1)), (sx0 - x, sy0 - y))
            im = cv
    z = e.get("resize") or {}
    W, H = im.size
    s = 1.0
    if z.get("mode") == "percent":
        s = fnum(z.get("value"), 100) / 100.0
    elif z.get("mode") == "long":
        s = fnum(z.get("value"), max(W, H)) / float(max(W, H))
    if s > 0 and abs(s - 1) > 1e-4:
        im = im.resize((max(1, round(W * s)), max(1, round(H * s))), RS.LANCZOS)
    return im


def to_mode(im, mode):
    if mode == "1":
        return im.convert("L").point(lambda v: 255 if v >= 128 else 0).convert("1", dither=DT.NONE)
    if mode in ("L", "LA") and im.mode != "L":
        return im.convert("L")
    if mode == "CMYK":
        return im.convert("CMYK")
    if mode not in ("L", "1") and im.mode != "RGB":
        return im.convert("RGB")
    return im


def ref_info(path):
    with Image.open(path) as im:
        return {"mode": im.mode, "dpi": im.info.get("dpi"), "compression": im.info.get("compression"),
                "icc": im.info.get("icc_profile")}


ENC = {"p": None, "off": False, "lock": threading.Lock()}


def enc_proc():
    """저장 도우미 프로세스 (없으면 띄움). 띄울 수 없으면 None → 본 프로세스에서 저장"""
    if ENC["off"]:
        return None
    p = ENC["p"]
    if p is not None and p.poll() is None:
        return p
    try:
        flags = 0
        if os.name == "nt":
            flags = 0x08000000  # 창 없이
        p = subprocess.Popen([sys.executable, os.path.join(APP_DIR, "enc_worker.py")], stdin=subprocess.PIPE,
                             stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, creationflags=flags)
        ENC["p"] = p
        return p
    except Exception:
        traceback.print_exc()
        ENC["off"] = True
        return None


def enc_stop():
    p = ENC["p"]
    if p is not None:
        try:
            p.stdin.close()
            p.terminate()
        except Exception:
            pass


atexit.register(enc_stop)


def save_render(base_path, ref_path, tp, e, pre, orig_out=None):
    """수정 내용을 원래 크기 이미지에 적용해 tp 에 저장 (순수 계산 — 본 프로세스·도우미 어디서나 같음)
    orig_out 이 있으면 '원본 수정'을 적용한 이미지를 원본 파일에도 덮어씀 (백업 없음 — 사용자가 정함)"""
    ref = ref_info(ref_path)
    ref_o = ref_info(orig_out) if (orig_out and pre) else None
    with Image.open(base_path) as im:
        im.load()
        src = im.copy()
    if pre:  # 원본 수정 → 보정 순서
        src = apply_edits(src, pre)
    out = to_mode(apply_edits(src, e), ref["mode"])
    write_image(out, tp, ref)
    if ref_o:  # 보정본을 먼저 쓴 뒤 원본을 바꿈
        write_image(to_mode(src, ref_o["mode"]), orig_out, ref_o)
    del src
    return list(out.size)


def enc_job(base_path, ref_path, tp, e, pre, orig_out=None):
    """저장 한 건을 도우미 프로세스에 통째로 맡김 (열기·수정 적용·압축·쓰기).
    결과 크기 [w, h] 를 돌려줌. 도우미를 쓸 수 없으면 None → 본 프로세스에서 저장. 도우미가 낸 저장 오류는 그대로 예외"""
    with ENC["lock"]:
        p = enc_proc()
        if p is None:
            return None
        try:
            job = {"base": base_path, "ref": ref_path, "tp": tp, "e": e, "pre": pre, "cfg": CFG, "orig_out": orig_out}
            p.stdin.write((json.dumps(job) + "\n").encode("utf-8"))
            p.stdin.flush()
            wd = threading.Timer(180, p.kill)  # 3분 넘게 답이 없으면 도우미를 끄고 본 프로세스에서 저장
            wd.daemon = True
            wd.start()
            try:
                line = p.stdout.readline()
            finally:
                wd.cancel()
            if not line:
                raise EOFError("저장 도우미가 응답하지 않습니다")
            r = json.loads(line.decode("utf-8"))
        except Exception:
            traceback.print_exc()
            try:
                p.kill()
            except Exception:
                pass
            ENC["p"] = None
            ENC["fail"] = ENC.get("fail", 0) + 1
            if ENC["fail"] >= 2:
                ENC["off"] = True  # 두 번 실패하면 이후로는 본 프로세스에서 저장
            return None
    if not r.get("ok"):
        raise IOError(r.get("err") or "저장 실패")
    return r.get("size")


def write_image(im, path, ref):
    ext = os.path.splitext(path)[1].lower()
    fmt = FMT.get(ext, "TIFF")
    kw = {}
    if ref.get("dpi"):
        try:
            kw["dpi"] = tuple(int(round(float(x))) for x in ref["dpi"])
        except Exception:
            pass
    if ref.get("icc") and im.mode == ref.get("mode"):
        kw["icc_profile"] = ref["icc"]
    if fmt == "TIFF":
        comp = ref.get("compression") or "tiff_lzw"
        if comp in ("group3", "group4"):
            if im.mode != "1":
                comp = "tiff_lzw"
        elif comp not in ("raw", "tiff_lzw", "tiff_adobe_deflate", "tiff_deflate", "packbits"):
            comp = "tiff_lzw"
        kw["compression"] = comp
    elif fmt == "JPEG":
        if im.mode not in ("RGB", "L", "CMYK"):
            im = im.convert("RGB")
        kw.update(quality=100, subsampling=0)
    tmp = path + ".scanqc_tmp"
    im.save(tmp, fmt, **kw)
    os.replace(tmp, path)


def backup_path(hp_path):
    return os.path.join(BACKUP_DIR, folder_tag(os.path.dirname(hp_path)), os.path.basename(hp_path))


def backup(hp_path):
    if not CFG.get("backup", True) or not hp_path or not os.path.exists(hp_path):
        return
    dst = backup_path(hp_path)
    if not os.path.exists(dst):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.copy2(hp_path, dst)


def target_path(f):
    if f["hp"]:
        return f["hp"]
    rel = f.get("rel") or os.path.basename(f["orig"])
    tp = os.path.join(ST["hp_dir"], *rel.split("/"))
    os.makedirs(os.path.dirname(tp), exist_ok=True)  # 하위 폴더 구조 그대로
    return tp


DRAFTS = {}   # 창이 닫힐 때 저장할, 아직 저장 안 된 수정 내용 {파일명: (edits, status)}
DRAFT_LOCK = threading.Lock()


def set_draft(name, edits, status):
    with DRAFT_LOCK:
        if edits:
            DRAFTS[name] = (edits, status if status in ("auto", "edited") else "edited")
        else:
            DRAFTS.pop(name, None)


def flush_drafts():
    """창이 닫히거나 엔진이 꺼질 때 남은 수정 내용을 저장"""
    with DRAFT_LOCK:
        items = list(DRAFTS.items())
        DRAFTS.clear()
    for name, (e, st) in items:
        try:
            do_save(name, e, st)
            log("save_on_close", name)
            print("[close-save] %s" % name)
        except Exception:
            traceback.print_exc()
    sess_flush()


ACTIVE = {"n": 0}
ACTIVE_LOCK = threading.Lock()


class busy:
    """저장·복사 중에는 자동 종료를 미룸"""
    def __enter__(self):
        with ACTIVE_LOCK:
            ACTIVE["n"] += 1

    def __exit__(self, *a):
        with ACTIVE_LOCK:
            ACTIVE["n"] -= 1


def do_copy(name):
    set_draft(name, None, None)
    f = get_file(name)
    if not f["orig"]:
        raise ValueError("원본 파일이 없습니다")
    tp = target_path(f)
    with plock(tp):
        backup(tp)
        tmp = tp + ".scanqc_tmp"
        if os.path.splitext(tp)[1].lower() == os.path.splitext(f["orig"])[1].lower():
            shutil.copyfile(f["orig"], tmp)
            os.replace(tmp, tp)
        else:
            with Image.open(f["orig"]) as im:
                im.load()
                write_image(im.copy(), tp, ref_info(f["orig"]))
        f["hp"] = tp
    set_status(name, "copied")
    log("copy_original", name)
    return {"status": "copied"}


def do_save(name, e, status="edited"):
    status = status if status in ("auto", "edited", "copied") else "edited"
    f = get_file(name)
    base_side = "orig" if (e.get("base") == "orig" or not f["hp"]) else "hp"
    if not f[base_side]:
        raise ValueError("기준 이미지 파일이 없습니다")
    pre = e.get("pre") if base_side == "orig" else None
    if base_side == "orig" and is_default(e) and not pre:
        r = do_copy(name)  # 보정할 것이 없으면 원본을 그대로 복사
        if status == "auto":
            set_status(name, "auto")
            r["status"] = "auto"
        return r
    tp = target_path(f)
    t0 = time.time()
    with plock(tp):
        with Image.open(f[base_side]) as im:
            need = im.size[0] * im.size[1] * (1 if im.mode in ("1", "L", "P") else 3)
        ref_path = f["hp"] or f["orig"]
        backup(tp)
        orig_out = f["orig"] if (pre and not is_default(dict(pre, base="orig"))) else None  # 원본 수정이 있으면 원본 파일도 저장
        size = enc_job(f[base_side], ref_path, tp, e, pre, orig_out)  # 도우미 프로세스에서 (화면·미리 읽기를 막지 않음)
        if size is None:
            with MemGate(need * 2):
                size = save_render(f[base_side], ref_path, tp, e, pre, orig_out)
        if orig_out:
            log("save_orig", name, json.dumps(pre, ensure_ascii=False))
        f["hp"] = tp
        mem_trim()
    set_status(name, status)
    log("save_auto" if status == "auto" else "save", name, json.dumps(e, ensure_ascii=False))
    print("[save] %s  %.2fs" % (name, time.time() - t0))
    return {"status": status, "size": size, "orig_saved": bool(orig_out)}


def do_restore(name):
    f = get_file(name)
    if not f["hp"]:
        raise ValueError("보정본이 없습니다")
    b = backup_path(f["hp"])
    if not os.path.exists(b):
        raise ValueError("백업이 없습니다")
    with plock(f["hp"]):
        tmp = f["hp"] + ".scanqc_tmp"
        shutil.copyfile(b, tmp)
        os.replace(tmp, f["hp"])
    set_status(name, "")
    log("restore", name)
    return {"status": ""}


def analyze_pre(name, pre):
    """원본 수정(pre)을 미리보기 크기로 적용한 뒤 자동 보정·검사를 다시 계산"""
    f = get_file(name)
    if not f["orig"]:
        raise ValueError("원본 파일이 없습니다")
    pv = get_preview(f["orig"])
    meta = pv["meta"]
    im = Image.open(io.BytesIO(pv["jpeg"]))
    im.load()
    if meta["mode"] in ("1", "L", "LA", "I", "I;16", "I;16B", "I;16L"):
        im = im.convert("L")
    k = im.width / float(max(1, meta["w"]))
    out = apply_edits(im, dict(pre, resize={"mode": "none"}), k)
    m2 = dict(meta, w=int(round(out.width / k)), h=int(round(out.height / k)))
    g = out.convert("L")
    g.thumbnail((1000, 1000), RS.BILINEAR)
    return {"meta": m2, "an": analyze(np.asarray(g, dtype=np.uint8), m2)}


# ---------------------------------------------------------------- folder picker
PICK_LOCK = threading.Lock()


FOLDER_PICKER_CS = r'''
using System;
using System.Runtime.InteropServices;
public static class ScanQCFolderPicker {
    [ComImport, Guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")]
    private class FileOpenDialogRCW { }

    [ComImport, Guid("42f85136-db7e-439c-85f1-e4075d135fc8"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IFileDialog {
        [PreserveSig] int Show(IntPtr parent);
        void SetFileTypes(uint cFileTypes, IntPtr rgFilterSpec);
        void SetFileTypeIndex(uint iFileType);
        void GetFileTypeIndex(out uint piFileType);
        void Advise(IntPtr pfde, out uint pdwCookie);
        void Unadvise(uint dwCookie);
        void SetOptions(uint fos);
        void GetOptions(out uint pfos);
        void SetDefaultFolder(IShellItem psi);
        void SetFolder(IShellItem psi);
        void GetFolder(out IShellItem ppsi);
        void GetCurrentSelection(out IShellItem ppsi);
        void SetFileName([MarshalAs(UnmanagedType.LPWStr)] string pszName);
        void GetFileName([MarshalAs(UnmanagedType.LPWStr)] out string pszName);
        void SetTitle([MarshalAs(UnmanagedType.LPWStr)] string pszTitle);
        void SetOkButtonLabel([MarshalAs(UnmanagedType.LPWStr)] string pszText);
        void SetFileNameLabel([MarshalAs(UnmanagedType.LPWStr)] string pszLabel);
        void GetResult(out IShellItem ppsi);
        void AddPlace(IShellItem psi, int fdap);
        void SetDefaultExtension([MarshalAs(UnmanagedType.LPWStr)] string pszDefaultExtension);
        void Close(int hr);
        void SetClientGuid(ref Guid guid);
        void ClearClientData();
        void SetFilter(IntPtr pFilter);
    }

    [ComImport, Guid("43826D1E-E718-42EE-BC55-A1E261C37BFE"), InterfaceType(ComInterfaceType.InterfaceIsIUnknown)]
    private interface IShellItem {
        void BindToHandler(IntPtr pbc, ref Guid bhid, ref Guid riid, out IntPtr ppv);
        void GetParent(out IShellItem ppsi);
        void GetDisplayName(uint sigdnName, [MarshalAs(UnmanagedType.LPWStr)] out string ppszName);
        void GetAttributes(uint sfgaoMask, out uint psfgaoAttribs);
        void Compare(IShellItem psi, uint hint, out int piOrder);
    }

    [DllImport("shell32.dll", CharSet = CharSet.Unicode, PreserveSig = false)]
    private static extern void SHCreateItemFromParsingName(string pszPath, IntPtr pbc,
        [In, MarshalAs(UnmanagedType.LPStruct)] Guid riid, out IShellItem ppv);

    public static string Pick(string title, string initial, IntPtr owner) {
        IFileDialog dlg = (IFileDialog)new FileOpenDialogRCW();
        // FOS_PICKFOLDERS | FOS_FORCEFILESYSTEM | FOS_PATHMUSTEXIST | FOS_NOCHANGEDIR
        dlg.SetOptions(0x20 | 0x40 | 0x800 | 0x8);
        dlg.SetTitle(title);
        dlg.SetOkButtonLabel("폴더 선택");
        if (!string.IsNullOrEmpty(initial) && System.IO.Directory.Exists(initial)) {
            try {
                IShellItem item;
                SHCreateItemFromParsingName(initial, IntPtr.Zero, typeof(IShellItem).GUID, out item);
                dlg.SetFolder(item);
            } catch { }
        }
        if (dlg.Show(owner) != 0) return "";
        IShellItem res;
        dlg.GetResult(out res);
        string path;
        res.GetDisplayName(0x80058000, out path);  // SIGDN_FILESYSPATH
        return path ?? "";
    }
}
'''


def pick_folder(title, initial):
    """Windows 기본 폴더 선택 창을 띄우고 고른 경로를 돌려줌 (취소 시 빈 문자열)."""
    import subprocess, base64
    initial = clean_path(initial)
    if not os.path.isdir(initial):
        initial = ""
    if os.name != "nt":
        try:  # 개발용(비 Windows) 대체
            import tkinter as tk
            from tkinter import filedialog
            r = tk.Tk(); r.withdraw(); r.attributes("-topmost", True)
            v = filedialog.askdirectory(title=title, initialdir=initial or None) or ""
            r.destroy()
            return os.path.normpath(v) if v else ""
        except Exception:
            raise ValueError("이 환경에서는 폴더 선택 창을 열 수 없습니다. 경로를 직접 입력하세요")
    esc = lambda t: (t or "").replace("'", "''")
    t, ini = esc(title), esc(initial)
    # 탐색기와 같은 최신 폴더 선택 창 (Windows 기본 IFileOpenDialog, 폴더 선택 모드).
    # 만들 수 없는 환경이면 예전 폴더 찾아보기 창으로 대체.
    ps = (
        "[Console]::OutputEncoding=[Text.Encoding]::UTF8\n"
        "Add-Type -AssemblyName System.Windows.Forms\n"
        "$o=New-Object System.Windows.Forms.Form -Property @{TopMost=$true;ShowInTaskbar=$false;Opacity=0;StartPosition='CenterScreen'}\n"
        "$o.Show();$o.Activate()\n"
        "$r=''\n"
        "try{\n"
        "Add-Type -Language CSharp -TypeDefinition @'\n" + FOLDER_PICKER_CS + "\n'@\n"
        "$r=[ScanQCFolderPicker]::Pick('" + t + "','" + ini + "',$o.Handle)\n"
        "}catch{\n"
        "$d=New-Object System.Windows.Forms.FolderBrowserDialog;$d.Description='" + t + "';$d.ShowNewFolderButton=$false\n"
        "if('" + ini + "'){$d.SelectedPath='" + ini + "'}\n"
        "if($d.ShowDialog($o) -eq [System.Windows.Forms.DialogResult]::OK){$r=$d.SelectedPath}\n"
        "}\n"
        "$o.Close()\n"
        "if($r){Write-Output $r}\n"
    )
    enc = base64.b64encode(ps.encode("utf-16-le")).decode("ascii")
    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
    out = subprocess.run(["powershell", "-NoProfile", "-STA", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                         capture_output=True, timeout=600, creationflags=flags)
    return out.stdout.decode("utf-8", "replace").strip().lstrip("\ufeff")


# ---------------------------------------------------------------- http
class Handler(BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype="application/json; charset=utf-8"):
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def _json(self, obj, code=200):
        self._send(code, json.dumps(obj, ensure_ascii=False).encode("utf-8"))

    def _body(self):
        n = int(self.headers.get("Content-Length") or 0)
        return json.loads(self.rfile.read(n).decode("utf-8")) if n else {}

    def _wrap(self, fn):
        try:
            fn()
        except (BrokenPipeError, ConnectionResetError, ConnectionAbortedError):
            pass
        except FileNotFoundError as ex:
            self._json({"error": str(ex)}, 404)
        except ValueError as ex:
            self._json({"error": str(ex)}, 400)
        except Exception as ex:
            traceback.print_exc()
            try:
                self._json({"error": "%s: %s" % (type(ex).__name__, ex)}, 500)
            except Exception:
                pass

    def do_GET(self):
        self._wrap(self._get)

    def do_POST(self):
        self._wrap(self._post)

    def _get(self):
        u = urlparse(self.path)
        q = {k: v[0] for k, v in parse_qs(u.query).items()}
        if u.path == "/favicon.ico":
            ico = os.path.join(STATIC, "app.ico")
            if os.path.exists(ico):
                with open(ico, "rb") as fh:
                    self._send(200, fh.read(), "image/x-icon")
            else:
                self._json({"error": "not found"}, 404)
            return
        if u.path.startswith("/fonts/"):  # 함께 넣은 글꼴 (인터넷 없이도 같은 모양)
            fn = os.path.basename(u.path)
            fp = os.path.join(STATIC, "fonts", fn)
            if fn.endswith(".woff2") and os.path.isfile(fp):
                with open(fp, "rb") as fh:
                    self._send(200, fh.read(), "font/woff2")
            else:
                self._json({"error": "not found"}, 404)
            return
        if u.path in ("/", "/index.html"):
            with open(os.path.join(STATIC, "index.html"), "rb") as fh:
                self._send(200, fh.read(), "text/html; charset=utf-8")
        elif u.path == "/api/config":
            self._json({"cfg": CFG, "version": VERSION})
        elif u.path == "/api/image":
            f = get_file(q.get("name"))
            side = q.get("side")
            if side not in ("hp", "orig") or not f[side]:
                raise FileNotFoundError("이미지 없음")
            PF["fg"] += 1
            try:
                data = get_full(f[side]) if q.get("full") == "1" else get_preview(f[side])["jpeg"]
            finally:
                PF["fg"] -= 1
            self._send(200, data, "image/jpeg")
        elif u.path == "/api/info":
            PF["fg"] += 1
            try:
                v = get_info(q.get("name"), cur=q.get("cur") == "1")
            finally:
                PF["fg"] -= 1
            self._json(v)
        else:
            self._json({"error": "not found"}, 404)

    def _post(self):
        p = urlparse(self.path).path
        b = self._body()
        if p == "/api/open":
            self._json(open_folders(b.get("hp"), b.get("orig")))
        elif p == "/api/draft":
            get_file(b["name"])
            set_draft(b["name"], b.get("edits"), b.get("status"))
            self._json({"ok": True})
        elif p == "/api/save":
            set_draft(b["name"], None, None)
            with busy():
                self._json(do_save(b["name"], b.get("edits") or {}, b.get("status") or "edited"))
        elif p == "/api/copy":
            set_draft(b["name"], None, None)
            with busy():
                self._json(do_copy(b["name"]))
        elif p == "/api/analyze":
            self._json(analyze_pre(b["name"], b.get("pre") or {}))
        elif p == "/api/ping":
            LIFE["ping"] = time.time()
            LIFE["bye"] = 0
            self._json({"ok": True})
        elif p == "/api/bye":
            LIFE["bye"] = time.time()
            self._json({"ok": True})
        elif p == "/api/restore":
            set_draft(b["name"], None, None)
            self._json(do_restore(b["name"]))
        elif p == "/api/status":
            get_file(b["name"])
            set_status(b["name"], b.get("status", ""))
            if b.get("status") == "ok":
                log("ok", b["name"])
            self._json({"ok": True})
        elif p == "/api/open_file":
            self._json(open_file(b.get("path")))
        elif p == "/api/pick_file":
            if not PICK_LOCK.acquire(blocking=False):
                raise ValueError("선택 창이 이미 열려 있습니다")
            try:
                self._json({"path": pick_file(b.get("initial") or "")})
            finally:
                PICK_LOCK.release()
        elif p == "/api/pick_folder":
            if not PICK_LOCK.acquire(blocking=False):
                raise ValueError("폴더 선택 창이 이미 열려 있습니다")
            try:
                self._json({"path": pick_folder(b.get("title") or "폴더 선택", b.get("initial") or "")})
            finally:
                PICK_LOCK.release()
        elif p == "/api/prefetch":
            names = list(b.get("names") or [])[:30]
            PF["tok"] += 1
            PREV.n = max(14, 2 * len(names) + 6)  # 미리 읽은 장수만큼 미리보기 보관
            EXEC.submit(prefetch, names, ST["gen"], PF["tok"])
            self._json({"ok": True})
        elif p == "/api/settings":
            for k in DEFAULT_CFG:
                if k in b and k not in ("hp_dir", "orig_dir"):
                    CFG[k] = b[k]
            save_json(CFG_PATH, CFG)
            self._json({"cfg": CFG})
        elif p == "/api/shutdown":
            flush_drafts()
            self._json({"ok": True})
            threading.Thread(target=self.server.shutdown, daemon=True).start()
        else:
            self._json({"error": "not found"}, 404)


# ---------------------------------------------------------------- app window / lifetime
LIFE = {"start": time.time(), "ping": 0.0, "bye": 0.0}


def open_app(url):
    """Edge(없으면 Chrome)를 주소창 없는 '앱 창'으로 열기. 둘 다 없으면 기본 브라우저."""
    env = os.environ.get
    cands = []
    for base in (env("ProgramFiles(x86)"), env("ProgramFiles"), env("LOCALAPPDATA")):
        if base:
            cands += [os.path.join(base, "Microsoft", "Edge", "Application", "msedge.exe"),
                      os.path.join(base, "Google", "Chrome", "Application", "chrome.exe")]
    prof = os.path.join(env("LOCALAPPDATA") or DATA, "ScanQC", "browser")
    for exe in cands:
        if os.path.isfile(exe):
            try:
                subprocess.Popen([exe, "--app=" + url, "--user-data-dir=" + prof, "--start-maximized",
                                  "--no-first-run", "--no-default-browser-check", "--disable-features=Translate",
                                  "--force-dark-mode"],
                                 creationflags=getattr(subprocess, "CREATE_NO_WINDOW", 0))
                return
            except Exception:
                traceback.print_exc()
    webbrowser.open(url)


def watchdog(srv, auto_exit):
    """창을 닫으면(신호 'bye' 후 6초간 소식 없음) 엔진 종료. 저장 중이면 끝날 때까지 기다림."""
    while True:
        time.sleep(1)
        if not auto_exit:
            continue
        now = time.time()
        closed = LIFE["bye"] and now - LIFE["bye"] > 6
        lost = LIFE["ping"] and now - LIFE["ping"] > 600          # 10분간 응답 없음
        never = not LIFE["ping"] and now - LIFE["start"] > 180    # 창이 끝내 안 열림
        if (closed or lost or never) and ACTIVE["n"] == 0:
            print("[exit] window closed" if closed else "[exit] no window")
            flush_drafts()
            srv.shutdown()
            return


def main():
    url = "http://127.0.0.1:%d" % PORT
    no_browser = "--no-browser" in sys.argv
    try:
        srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    except OSError:
        print("ScanQC is already running -> " + url)
        if not no_browser:
            open_app(url)
        return
    srv.daemon_threads = True
    print("=" * 46)
    print("  ScanQC %s  |  %s" % (VERSION, url))
    print("  Closing the ScanQC window stops it automatically")
    print("=" * 46)
    if not no_browser:
        threading.Timer(0.6, lambda: open_app(url)).start()
    threading.Thread(target=watchdog, args=(srv, "--keep-alive" not in sys.argv and not no_browser), daemon=True).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass
    flush_drafts()


if __name__ == "__main__":
    try:
        main()
    except Exception:
        msg = traceback.format_exc()
        print(msg)
        try:
            with open(os.path.join(DATA, "error.log"), "a", encoding="utf-8") as f:
                f.write(time.strftime("[%Y-%m-%d %H:%M:%S]\n") + msg + "\n")
        except Exception:
            pass
        sys.exit(1)
