# -*- coding: utf-8 -*-
"""저장 도우미 (별도 프로세스)

저장 한 건(원래 크기로 열기 → 수정 적용 → 압축 → 파일 쓰기)을 통째로 맡는다.
본 프로그램과 다른 프로세스라서 저장하는 동안에도 다음 장 불러오기가 멈추지 않는다.

주고받는 형식 (표준 입출력, 한 줄에 JSON 하나):
  요청: {"base": 읽을 파일, "ref": 형식 기준 파일, "tp": 저장할 경로, "e": 수정 내용, "pre": 원본 수정, "cfg": 설정}
  응답: {"ok": true, "size": [w, h]} 또는 {"ok": false, "err": "..."}
"""
import json
import os
import sys


def main():
    fin = sys.stdin.buffer
    fout = os.fdopen(os.dup(sys.stdout.fileno()), "wb")
    sys.stdout = open(os.devnull, "w")  # 본 프로그램 쪽 안내 출력이 응답에 섞이지 않게
    sys.argv = [sys.argv[0], "--no-browser"]
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import server  # 수정 적용·저장 코드를 그대로 씀 (서버는 띄우지 않음)
    server.ENC["off"] = True
    while True:
        line = fin.readline()
        if not line:
            return
        try:
            j = json.loads(line.decode("utf-8"))
            server.CFG.update(j.get("cfg") or {})
            size = server.save_render(j["base"], j["ref"], j["tp"], j.get("e") or {}, j.get("pre"), j.get("orig_out"))
            res = {"ok": True, "size": size}
        except Exception as e:  # noqa
            res = {"ok": False, "err": "%s: %s" % (type(e).__name__, e)}
        fout.write((json.dumps(res) + "\n").encode("utf-8"))
        fout.flush()


if __name__ == "__main__":
    main()
